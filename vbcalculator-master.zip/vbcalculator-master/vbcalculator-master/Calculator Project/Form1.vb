﻿'Project: calculator
'Purpose: to develop a simple calculator, to use use independent subprocedures
'Name: Howard Huang, Elizabeth Lee, Kobin Deary

Public Class frmMain
    'indepedent subprocedure for adding
    Private Sub Add(ByVal decNumber As Decimal, ByVal decNumber2 As Decimal)
        Dim decAnswer As Decimal = 0
        decAnswer = decNumber + decNumber2
        lblDisplay.Text = "Answer: " + decAnswer.ToString("N2")
    End Sub


    'independent subprocedure for subtracting
    Private Sub Subtract(ByVal decNumber As Decimal, ByVal decNumber2 As Decimal)
        Dim decAnswer As Decimal = 0
        decAnswer = decNumber - decNumber2
        lblDisplay.Text = "Answer: " + decAnswer.ToString("N2")

    End Sub

    'independent subprocedure for multiplying
    Private Sub Multiply(ByVal decNumber As Decimal, ByVal decNumber2 As Decimal)
        Dim decAnswer As Decimal = 0
        decAnswer = decNumber * decNumber2
        lblDisplay.Text = "Answer: " + decAnswer.ToString("N2")
    End Sub


    'independing subprocedure for dividing
    Private Sub Divide(ByVal decNumber As Decimal, ByVal decNumber2 As Decimal)
        Dim decAnswer As Decimal = 0
        decAnswer = decNumber / decNumber2
        lblDisplay.Text = "Answer: " + decAnswer.ToString("N2")
    End Sub
    Private Sub plusButton_Click(sender As Object, e As EventArgs) Handles plusButton.Click
        'adding
        Dim decNum1 As Decimal
        Dim decNum2 As Decimal
        Decimal.TryParse(txtNumber1.Text, decNum1)
        Decimal.TryParse(txtNumber2.Text, decNum2)


        Call Add(decNum1, decNum2)
    End Sub

    Private Sub minusButton_Click(sender As Object, e As EventArgs) Handles minusButton.Click
        'subtracting
        Dim decNum1 As Decimal
        Dim decNum2 As Decimal
        Decimal.TryParse(txtNumber1.Text, decNum1)
        Decimal.TryParse(txtNumber2.Text, decNum2)


        Call Subtract(decNum1, decNum2)
    End Sub

    Private Sub divideButton_Click(sender As Object, e As EventArgs) Handles divideButton.Click
        'dividing
        Dim decNum1 As Decimal
        Dim decNum2 As Decimal
        Decimal.TryParse(txtNumber1.Text, decNum1)
        Decimal.TryParse(txtNumber2.Text, decNum2)


        Call Divide(decNum1, decNum2)
    End Sub

    Private Sub multiplyButton_Click(sender As Object, e As EventArgs) Handles multiplyButton.Click
        'multiplying
        Dim decNum1 As Decimal
        Dim decNum2 As Decimal
        Decimal.TryParse(txtNumber1.Text, decNum1)
        Decimal.TryParse(txtNumber2.Text, decNum2)


        Call Multiply(decNum1, decNum2)
    End Sub

    Private Sub clearButton_Click(sender As Object, e As EventArgs) Handles clearButton.Click
        'clearing
        txtNumber1.Text = " "
        txtNumber2.Text = " "
        lblDisplay.Text = "Answer: "
    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub

    Private Sub Text_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNumber1.KeyPress, txtNumber2.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> "-" AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub
End Class
